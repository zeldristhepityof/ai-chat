# AI 단톡방 스튜디오 — 안드로이드 APK 추출 가이드

이 압축 파일에는 방금 만든 **AI 단톡방 스튜디오**를 안드로이드 스마트폰 설치 파일(`.apk`)로 바로 변환할 수 있는 전체 프로젝트와 단일 웹앱 파일(`app/src/main/assets/index.html`)이 들어 있습니다.

---

## 방법 1. 무설치 1분 변환 사이트 이용 (가장 간편함)
1. 이 압축 파일 안의 `app/src/main/assets/index.html` 파일을 꺼냅니다.
2. 무료 HTML → APK 변환 사이트에 접속합니다:
   - **WebIntoApp** (https://www.webintoapp.com/html-to-app)
   - **AppsGeyser** (https://appsgeyser.com/create-html-app/)
3. `index.html` 파일을 업로드하고 앱 이름을 **AI 단톡방**으로 입력한 뒤 **Make App / Build APK**를 누르면 1분 안에 `.apk` 파일을 다운로드할 수 있습니다.

---

## 방법 2. GitHub Actions로 클라우드에서 무료 자동 빌드 (PC에 프로그램 설치 불필요)
이 폴더에는 `.github/workflows/build-apk.yml` 자동 빌드 스크립트가 포함되어 있습니다.
1. GitHub에서 새 저장소(Repository)를 만들고 이 폴더의 파일들을 그대로 업로드(Push)합니다.
2. 상단 **Actions** 탭으로 이동하면 자동으로 `Build Android APK` 워크플로우가 실행됩니다.
3. 약 2분 뒤 빌드가 완료되면 하단 **Artifacts** 항목에서 **`ai-group-chat-debug-apk`**를 클릭해 완성된 `app-debug.apk`를 다운로드합니다.

---

## 방법 3. Android Studio에서 직접 빌드
1. PC에서 **Android Studio**를 실행하고 **Open**을 눌러 이 폴더(`AiGroupChatAndroid`)를 엽니다.
2. Gradle 동기화가 끝나면 상단 메뉴에서 **Build > Build Bundle(s) / APK(s) > Build APK(s)**를 클릭합니다.
3. `app/build/outputs/apk/debug/app-debug.apk` 경로에 생성된 APK 파일을 스마트폰으로 옮겨 설치합니다.
